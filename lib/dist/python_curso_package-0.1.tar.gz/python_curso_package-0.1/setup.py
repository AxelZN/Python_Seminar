import setuptools

setuptools.setup(
    name='python_curso_package',
    version='0.1',
    description='Functions from the python class',
    url='http://github.com/python-curso',
    author='Axel Zagal',
    author_email='azagal@lcg.unam.mx',
    packages=setuptools.find_packages(),
)
